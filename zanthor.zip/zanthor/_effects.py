#             q = parts[(n+1)%l]
#             dx,dy = q.x-p.x, q.y-p.y
#             dist = (abs(dx)+abs(dy))
#             d2 = dist*dist
#             f, f2 = 16, 16*16
#             if d2 > f2:
#                 cx,cy = (q.x+p.x)/2,(q.y+p.y)/2
#                 p.x,p.y = cx - dx*f/dist,cy - dy*f/dist
#                 q.x,q.y = cx + dx*f/dist,cy + dy*f/dist
#
