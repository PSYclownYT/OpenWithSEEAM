if __name__ == "__main__":
    from . import main

    main.main()
