if __name__ == "__main__":
    import zanthor.main
    zanthor.main.main()
