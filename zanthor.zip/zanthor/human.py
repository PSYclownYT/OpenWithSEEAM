"""
 to keep the state of the human.
"""


class Human:
    def __init__(self):
        """ """
        self.health = 1.0
        self.speed = 1.0
