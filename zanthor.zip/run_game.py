import sys

# sys.path.insert(0, "lib")

import zanthor.main

if __name__ == "__main__":
    zanthor.main.main()
